package com.api.auto.testcase;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.api.auto.utils.PropertiesFileUtils;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class TC_API_CreateWork {

	private String token;
	private Response response;
	private ResponseBody responseBody;
	private JsonPath jsonBody;
	
//Tự tạo data sẽ dùng 
	private String myWork = "Giang vien";
	private String myExperience = "3";
	private String myEducation = "Thac si";
	
	@BeforeClass
	public void init() {
// Đọc đường dẫn URL đã lưu từ file Config.properties, token từ file Token.properties file

		String baseUrl =PropertiesFileUtils.getProperty("baseUrl");
		String createWorkPath =PropertiesFileUtils.getProperty("createWorkPath");
		String token = PropertiesFileUtils.getToken("token");

		RestAssured.baseURI = baseUrl;
// Tạo và đọc body dưới dạng JSON
		Map<String, Object> inforCreated= new HashMap<String, Object>();
		inforCreated.put("nameWork",myWork);
		inforCreated.put("experience",myExperience); 
		inforCreated.put("education",myEducation); 

		RequestSpecification request = RestAssured.given()
				.contentType(ContentType.JSON)
				.header("token", token)
				.body(inforCreated);

		response = request.post(createWorkPath);
		responseBody = response.body();
		jsonBody = responseBody.jsonPath();

		System.out.println(" " + responseBody.asPrettyString());
	}

//THỰC HIỆN TESTCASE, CÀI ĐẶT THỨ TỰ ƯU TIÊN TEST NẾU CẦN
	@Test(priority = 0)
	public void TC01_Validate201Created() {
// Kiểm chứng status code có là 201 hay không
		assertEquals(response.getStatusCode(), 201);
		System.out.println("\nStatus code is: " + response.getStatusCode()+"\n");
	}

	@Test(priority = 1)
	public void TC02_ContainWorkId() {
// Kiểm chứng response body có chứa trường message hay không
		assertTrue(responseBody.asString().contains("id"), "Id field check Failed!");
  	}

	@Test(priority = 2)
	public void TC03_ContainNameOfWork() {
// Kiểm chứng response body có chứa trường nameWork hay không
		assertTrue(responseBody.asString().contains( "nameWork"), "nameWork field check Failed!");
	}
	
	@Test(priority = 3)
	public void TC04_ValidateNameOfWorkMatched() {
// Kiểm chứng trường nameWork có khớp với thông tin myWork đã tạo hay không
		assertEquals(jsonBody.getString("nameWork"), myWork,"nameWork check Failed!");
	}
	
	@Test(priority = 4)
	public void TC05_ContainExperienceOfWork() {
// Kiểm chứng response body có chứa trường experience hay không
		assertTrue(responseBody.asString().contains( "experience"), "experience field check Failed!");
	}

	@Test(priority = 5)
	public void TC06_ValidateExperienceMatched() {
// Kiểm chứng trường experience có khớp với thông tin myExperience đã tạo hay không
		assertEquals(jsonBody.getString("experience"), myExperience,"experience check Failed!");
	}
	
	@Test(priority = 6)
	public void TC07_ContainEducationOfUser() {
// Kiểm chứng response body có chứa trường education hay không
		assertTrue(responseBody.asString().contains( "education"), "education field check Failed!");
	}

	@Test(priority = 7)
	public void TC08_ValidateEducationMatched() {
// Kiểm chứng trường education có khớp với thông tin myEducation đã tạo hay không
		assertEquals(jsonBody.getString("education"), myEducation,"education check Failed!");
	}
}
