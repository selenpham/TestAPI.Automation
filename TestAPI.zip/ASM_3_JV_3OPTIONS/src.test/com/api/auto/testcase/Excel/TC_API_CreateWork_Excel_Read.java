package com.api.auto.testcase.Excel;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class TC_API_CreateWork_Excel_Read {
	String postEndPoint = "http://13.228.39.1:5000";
    String createWorkPath = "/api/work-user/createWork-user";

    RequestSpecification request;
    Response postresponse;
    ResponseBody responseBody;
    JsonPath bodyJson;
    String jsonContent;
    private String token ;
    File jsonBody;

 // Đọc giá trị từ file excel TokenSave.xlsx
    private String readExcelValue(String filePath, String sheetName, int rowIndex, int cellIndex) throws IOException {
        FileInputStream fis = new FileInputStream("./ExceFilelWriten/TokenSave.xlsx");
        XSSFWorkbook wk = new XSSFWorkbook(fis);
        XSSFSheet s1 = wk.getSheet("TokenWriten");
        XSSFRow r1 = s1.getRow(rowIndex);
        XSSFCell c1 = r1.getCell(cellIndex);
        String token = c1.getStringCellValue();
        wk.close();
        fis.close();
        return token;
        
    }

    @BeforeMethod
    public void setConfiguration() throws IOException {

        // đăt giá trị biến
        String tokenFilePath = "./ExceFilelWriten/TokenSave.xlsx";
        String sheetName = "TokenWriten";
        int rowIndex = 1; // Assuming the token value is stored in the second row
        int cellIndex = 0; // Assuming the token value is stored in the first cell of the row
        this.token = readExcelValue(tokenFilePath, sheetName, rowIndex, cellIndex);

        String inputData = "";

        File jsonBody = new File("./RequestPayload/CreateWork.json");
        FileReader fr = new FileReader(jsonBody);
        BufferedReader br = new BufferedReader(fr);
        jsonContent = br.readLine();

        while (jsonContent != null) {
            inputData = inputData + jsonContent;
            jsonContent = br.readLine();
        }
        
        request = RestAssured.given();
        request.baseUri(postEndPoint);
        request.basePath(createWorkPath);

        // Set the token value as a header
        request.header("token", token);
        
        request.header("content-type", "application/json");

        request.body(inputData);

        postresponse = request.post();
        responseBody = postresponse.getBody();
        bodyJson = responseBody.jsonPath();
	}
    
 
//THỰC HIỆN TESTCASE, CÀI ĐẶT THỨ TỰ ƯU TIÊN TEST NẾU CẦN
    @Test(priority = 1)
    public void TC01_Validate201Created() {
        // Kiểm chứng status code có là 201 hay không
        assertEquals(postresponse.getStatusCode(), 201);
        System.out.println("\nStatus code is: " + postresponse.getStatusCode()+"\n");
        System.out.println(" " + postresponse.asPrettyString());
    }

    @Test(priority = 2)
    public void TC02_ContainWorkId() {
 // Kiểm chứng response body có chứa trường id hay không
        assertTrue(postresponse.asString().contains("id"), "Id field check Failed!");
    }

    @Test(priority = 3)
    public void TC03_ContainNameOfWork() {
// Kiểm chứng response body có chứa trường nameWork hay không
        assertTrue(postresponse.asString().contains("nameWork"), "nameWork field check Failed!");
    }

    @Test(priority = 4)
    public void TC04_ValidateNameOfWorkMatched() {
// Kiểm chứng trường nameWork có khớp với thông tin đã tạo hay không
        assertEquals(bodyJson.getString("nameWork"), "Giang vien","nameWork check Failed!");
    }

    @Test(priority = 5)
    public void TC05_ContainExperienceOfWork() {
// Kiểm chứng response body có chứa trường experience hay không
        assertTrue(postresponse.asString().contains("experience"), "experience field check Failed!");
    }

    @Test(priority = 6)
    public void TC06_ValidateExperienceMatched() {
// Kiểm chứng trường experience có khớp với thông tin myExperience đã tạo hay không
        assertEquals(bodyJson.getString("experience"), "3","experience check Failed!");
    }

    @Test(priority = 7)
    public void TC07_ContainEducationOfUser() {
// Kiểm chứng response body có chứa trường education hay không
        assertTrue(postresponse.asString().contains("education"), "education field check Failed!");
    }

    @Test(priority = 8)
    public void TC08_ValidateEducationMatched() {
// Kiểm chứng trường education có khớp với thông tin myEducation đã tạo hay không
        assertEquals(bodyJson.getString("education"), "Thac si","education check Failed!");
    }

}