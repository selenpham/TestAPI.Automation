package com.api.auto.testcase.Excel;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.api.auto.utils.PropertiesFileUtils;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class TC_API_Login_Excel_Writen {
	
//TẠO LỆNH VIẾT TOKEN VÀO EXCEL 	
	public static void writeToExcelFile(ArrayList<Token> TokenSave) {

		XSSFWorkbook wk = new XSSFWorkbook();
		XSSFSheet s1 = wk.createSheet("TokenWriten");
		XSSFRow r1 = s1.createRow(0);

// Tạo và gán giá trị cho các cột 0 với tên gọi là Token
		XSSFCell c1 = r1.createCell(0);
		c1.setCellValue("TokenValue");

// Tạo vòng lặp for để gán các giá trị sẽ nhập sẽ được ghi vào cột và dòng tương ứng trong excel file
		for (int i = 0; i < TokenSave.size(); i++) {
			Token std = TokenSave.get(i);
			XSSFRow row1 = s1.createRow(i + 1);
			XSSFCell cell1 = row1.createCell(0);
			cell1.setCellValue(String.valueOf(std.gettokenValue()));
		}

// Tạo lệnh báo nếu thông tin nhập đã được ghi lại trong file excel có tên là "TokenSave.xlsx"
// File excel này có đường path tại folder:"./ExceFilelWriten/TokenSave.xlsx"
		try {
			FileOutputStream out = new FileOutputStream(new File("./ExceFilelWriten/TokenSave.xlsx"));
			wk.write(out);
			out.close();
			System.out.println("TokenSave.xlsx written successfully on disk");
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
// ĐẶT CÁC BIẾN SỬ DỤNG TRONG TEST	
	
	String postEndPoint = "http://13.228.39.1:5000";
    String basePath = "/api/users/login";

    private String account;
	private String password;
	private Response postresponse;
	private ResponseBody responseBody;
	private JsonPath bodyJson;
	private String token ;

	@BeforeClass
	public void init() {
// Đọc đường dẫn URL và account/password đã lưu từ file Config.properties
		String baseUrl = PropertiesFileUtils.getProperty("baseUrl");
		String loginPath = PropertiesFileUtils.getProperty("loginPath");;
		account = PropertiesFileUtils.getProperty("accountLogin");
		password = PropertiesFileUtils.getProperty("passwordLogin");
		
		RestAssured.baseURI = baseUrl;

// Tạo và đọc body dưới dạng JSON
		Map<String, Object> user = new HashMap<String, Object>();
		user.put("account", account);
		user.put("password", password);

        RequestSpecification request = RestAssured.given()
                                 .contentType(ContentType.JSON)
                                 .body(user);

        postresponse = request.post(loginPath);
		responseBody = postresponse.body();
		bodyJson = responseBody.jsonPath();
		
		System.out.println("RESPONSE:"+"\n" + postresponse.asPrettyString());
	}

	
//THỰC HIỆN TESTCASE, CÀI ĐẶT THỨ TỰ ƯU TIÊN TEST NẾU CẦN
    @Test(priority = 1)
    public void T01_StatusCode200() {
// Kiểm chứng status code có là 200 hay không
        assertEquals(200, postresponse.getStatusCode(), "Status Check Failed!");
    }

    @Test(priority = 2)
    public void T02_ContainMessage() {
// Kiểm chứng response body có chứa trường message hay không
        assertTrue(postresponse.asString().contains("message"), "message field check Failed!");
    }

    @Test(priority = 3)
    public void T03_VerifyOnMatchMessage() {
// Kiểm chứng trường message có hiển thị nội dung "Đăng nhập thành công" hay không

    	 String resMessage = bodyJson.get("message");
        assertEquals(resMessage, "Đăng nhập thành công", "message field check Failed!");
    }
   
    @Test(priority = 4)
    public void TC04_ContainToken() throws Exception {
// Kiểm chứng response body có chứa trường token hay không
        token = bodyJson.getString("token");
        assertTrue(postresponse.asString().contains("token"), "Token field check Failed!");
    }
    
    @Test(priority = 5)
	public void TC05_SaveTokenToExcel() {

		ArrayList<Token> TokenSave = new ArrayList<Token>();
		Token token = new Token();
		token.settokenValue(bodyJson.getString("token"));
//Thêm token vào danh sách TokenSave
		TokenSave.add(token);
//Viết danh sách TokenSave vào file Excel
		writeToExcelFile(TokenSave);
		System.out.println("Token save successfully");
	}
   
	@Test(priority = 6)
	public void TC06_ContainUser() {
// Kiểm chứng response chứa thông tin user hay không
        assertTrue(postresponse.asString().contains("user"), "User field check Failed!");
	}
		
	@Test(priority = 7)
	public void TC07_ContainType() {
// Kiểm chứng response body có chứa thông tin trường type hay không
        assertTrue(postresponse.asString().contains("type"), "Type field check Failed!");
	}
	
	@Test(priority = 8)
    public void TC08_VerifyOnMatchType() {

// Kiểm chứng trường type nội dung có phải là “UNGVIEN” hay không
		assertEquals(bodyJson.getString("user.type"),"UNGVIEN", "Type check Failed!");
	}

	@Test(priority = 9)
	public void TC09_ContainAccount() {
// Kiểm chứng response body có chứa thông tin trường account hay không
        assertTrue(postresponse.asString().contains("account"), "account field check Failed!");
	}
	
	@Test(priority = 10)
	public void TC10_VerifyOnMatchAccount() {
// Kiểm chứng trường account có khớp với account đăng nhập đã cho hay không
		assertEquals(bodyJson.getString("user.account"), "testerFunix","Account check Failed!");
	}
	
	@Test(priority = 11)
	public void TC11_ValidatePassword()  {
 // Kiểm chứng response chứa thông tin trường password hay không
        assertTrue(postresponse.asString().contains("password"), "Type field check Failed!");
	}
	
	@Test(priority = 12)
	public void TC12_VerifyOnMatchPassword() {
// Kiểm chứng trường password có khớp với password đăng nhập đã cho hay không
		assertEquals(bodyJson.getString("user.password"), "Abc13579","Password check Failed!");
	}
}
