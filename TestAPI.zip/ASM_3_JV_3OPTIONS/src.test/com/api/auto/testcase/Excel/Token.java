package com.api.auto.testcase.Excel;

public class Token {
//	/Tạo đối tượng Token bao gồm các thông tin cơ bản: token
    private String tokenValue;
//Tạo phương thức get,set cho tokenValue
    public String gettokenValue() {
        return tokenValue;
    }
    public void settokenValue(String tokenValue) {
        this.tokenValue = tokenValue;
    }
}
