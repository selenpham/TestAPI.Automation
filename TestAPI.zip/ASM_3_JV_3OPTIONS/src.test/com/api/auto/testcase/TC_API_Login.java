package com.api.auto.testcase;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.api.auto.utils.PropertiesFileUtils;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class TC_API_Login {
// Gọi các biến sử dụng trong testcase
	private String account;
	private String password;
	private Response response;
	private ResponseBody responseBody;
	private JsonPath jsonBody;
	private String token ;
	
	@BeforeClass
	public void init() {
// Đọc đường dẫn URL và account/password đã lưu từ file Config.properties
		String baseUrl = PropertiesFileUtils.getProperty("baseUrl");
		String loginPath = PropertiesFileUtils.getProperty("loginPath");;
		account = PropertiesFileUtils.getProperty("accountLogin");
		password = PropertiesFileUtils.getProperty("passwordLogin");
		
		RestAssured.baseURI = baseUrl;

// Tạo và đọc body dưới dạng JSON
		Map<String, Object> user = new HashMap<String, Object>();
		user.put("account", account);
		user.put("password", password);

        RequestSpecification request = RestAssured.given()
                                 .contentType(ContentType.JSON)
                                 .body(user);

		response = request.post(loginPath);
		responseBody = response.body();
		jsonBody = responseBody.jsonPath();

		System.out.println(" " + responseBody.asPrettyString());
	}
	
//THỰC HIỆN TESTCASE, CÀI ĐẶT THỨ TỰ ƯU TIÊN TEST NẾU CẦN
	@Test(priority = 0)
	public void TC01_Validate200Ok() {
// Kiểm chứng status code có là 200 hay không
		assertEquals(response.getStatusCode(), 200);
		System.out.println("\nStatus code is: " + response.getStatusCode()+"\n");
	}

	@Test(priority = 1)
	public void TC02_ValidateMessage() {
// Kiểm chứng response body có chứa trường message hay không
		assertTrue(responseBody.asString().contains("message"), "Message field check Failed!");
	}
	
	@Test(priority = 2)
	public void TC03_VerifyOnMatchMessage() {
// Kiểm chứng trường message có hiển thị nội dung "Đăng nhập thành công" hay không
		assertEquals("Đăng nhập thành công",responseBody.jsonPath().getString("message"),"Message check Failed!");
	}

	@Test(priority = 3)
	public void TC04_ValidateToken() {
// Kiểm chứng response body có chứa trường token hay không
		token = jsonBody.getString("token");
        assertTrue(responseBody.asString().contains("token"), "Token field check Failed!");
// Lưu lại token đã chạy vào Token.properties để sử dụng ở phần CreateWork
        PropertiesFileUtils.saveToken("token", token);
        System.out.println("\nYour token is :" +token+"\n");
    }

	@Test(priority = 4)
	public void TC05_ValidateUser() {
// Kiểm chứng response chứa thông tin user hay không
        assertTrue(responseBody.asString().contains("user"), "User field check Failed!");
	}
		
	@Test(priority = 5)
	public void TC06_ValidateUserType() {
// Kiểm chứng response body có chứa thông tin trường type hay không
        assertTrue(responseBody.asString().contains("type"), "Type field check Failed!");
	}
	
	@Test(priority = 6)
    public void TC07_VerifyOnMatchType() {

// Kiểm chứng trường type nội dung có phải là “UNGVIEN” hay không
		assertEquals(jsonBody.getString("user.type"),"UNGVIEN", "Type check Failed!");
	}

	@Test(priority = 7)
	public void TC08_ValidateAccount() {
// Kiểm chứng response body có chứa thông tin trường account hay không
        assertTrue(responseBody.asString().contains("account"), "account field check Failed!");
	}
	
	@Test(priority = 8)
	public void TC09_VerifyOnMatchAccount() {
// Kiểm chứng trường account có khớp với account đăng nhập đã cho hay không
		assertEquals(jsonBody.getString("user.account"), account,"Account check Failed!");
	}
	
	@Test(priority = 9)
	public void TC10_ValidatePassword()  {
 // Kiểm chứng response chứa thông tin trường password hay không
        assertTrue(responseBody.asString().contains("password"), "Type field check Failed!");
	}
	
	@Test(priority = 10)
	public void TC11_VerifyOnMatchPassword() {
// Kiểm chứng trường password có khớp với password đăng nhập đã cho hay không
		assertEquals(jsonBody.getString("user.password"), password,"Password check Failed!");

	}
}