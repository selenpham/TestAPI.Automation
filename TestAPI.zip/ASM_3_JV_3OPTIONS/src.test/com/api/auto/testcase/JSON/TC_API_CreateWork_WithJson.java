package com.api.auto.testcase.JSON;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.File;

import java.io.FileReader;
import java.io.IOException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class TC_API_CreateWork_WithJson {
    String postEndPoint = "http://13.228.39.1:5000";
    String createWorkPath = "/api/work-user/createWork-user";

    RequestSpecification request;
    Response postresponse;
    ResponseBody responseBody;
    JsonPath bodyJson;
    String jsonContent;
    File jsonBody;
    Object JsonObject;

     @BeforeMethod
    public void setConfiguration() throws IOException {
        request = RestAssured.given();

        File tokenFile = new File("./RequestPayload/token.json");
        FileReader fileReader = new FileReader(tokenFile);
        JsonParser jsonParser = new JsonParser();
        JsonObject jsonObject = jsonParser.parse(fileReader).getAsJsonObject();
        String tokenValue = jsonObject.get("token").getAsString();
// Ghi giá trị token vào header
        request.header("token", tokenValue);
        
// Đọc dữ liệu từ file "./RequestPayload/CreateWork.json" 
        jsonBody = new File("./RequestPayload/CreateWork.json");
        String inputData = "";

        FileReader fr = new FileReader(jsonBody);
        BufferedReader br = new BufferedReader(fr);
        jsonContent = "";

        while (jsonContent != null) {
            inputData = inputData + jsonContent;
            jsonContent = br.readLine();
        }

        request.baseUri(postEndPoint);
        request.basePath(createWorkPath);

        request.body(inputData);
        request.header("content-type", "application/json");

        postresponse = request.post();
        responseBody = postresponse.getBody();
        bodyJson = responseBody.jsonPath();
    }
  
//THỰC HIỆN TESTCASE, CÀI ĐẶT THỨ TỰ ƯU TIÊN TEST NẾU CẦN
    @Test(priority = 1)
    public void TC01_Validate201Created() {
        // Kiểm chứng status code có là 201 hay không
        assertEquals(postresponse.getStatusCode(), 201);
        System.out.println("\nStatus code is: " + postresponse.getStatusCode()+"\n");
        System.out.println(" " + postresponse.asPrettyString());
    }

    @Test(priority = 2)
    public void TC02_ContainWorkId() {
 // Kiểm chứng response body có chứa trường id hay không
        assertTrue(postresponse.asString().contains("id"), "Id field check Failed!");
    }

    @Test(priority = 3)
    public void TC03_ContainNameOfWork() {
// Kiểm chứng response body có chứa trường nameWork hay không
        assertTrue(postresponse.asString().contains("nameWork"), "nameWork field check Failed!");
    }

    @Test(priority = 4)
    public void TC04_ValidateNameOfWorkMatched() {
// Kiểm chứng trường nameWork có khớp với thông tin đã tạo hay không
        assertEquals(bodyJson.getString("nameWork"), "Giang vien","nameWork check Failed!");
    }

    @Test(priority = 5)
    public void TC05_ContainExperienceOfWork() {
// Kiểm chứng response body có chứa trường experience hay không
        assertTrue(postresponse.asString().contains("experience"), "experience field check Failed!");
    }

    @Test(priority = 6)
    public void TC06_ValidateExperienceMatched() {
// Kiểm chứng trường experience có khớp với thông tin myExperience đã tạo hay không
        assertEquals(bodyJson.getString("experience"), "3","experience check Failed!");
    }

    @Test(priority = 7)
    public void TC07_ContainEducationOfUser() {
// Kiểm chứng response body có chứa trường education hay không
        assertTrue(postresponse.asString().contains("education"), "education field check Failed!");
    }

    @Test(priority = 8)
    public void TC08_ValidateEducationMatched() {
// Kiểm chứng trường education có khớp với thông tin myEducation đã tạo hay không
        assertEquals(bodyJson.getString("education"), "Thac si","education check Failed!");
    }

}