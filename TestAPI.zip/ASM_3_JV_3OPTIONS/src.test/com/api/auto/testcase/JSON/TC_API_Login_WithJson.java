package com.api.auto.testcase.JSON;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class TC_API_Login_WithJson {
	String postEndPoint = "http://13.228.39.1:5000";
    String basePath = "/api/users/login";

    RequestSpecification request;
    Response postresponse;
    ResponseBody resBody;
    JsonPath bodyJson;
    String jsonContent;
    private String token ;
    File jsonBody;
    FileWriter file;

    @BeforeMethod
    public void setConfiguration() throws IOException {

        String inputData = "";

        File jsonBody = new File("./RequestPayload/AddUserLoginRequest.json");
        FileReader fr = new FileReader(jsonBody);
        BufferedReader br = new BufferedReader(fr);
        jsonContent = br.readLine();

        while (jsonContent != null) {
            inputData = inputData + jsonContent;
            jsonContent = br.readLine();
        }

        request = RestAssured.given();
        request.baseUri(postEndPoint);
        request.basePath(basePath);

        request.header("content-type", "application/json");
        request.body(inputData);
//        System.out.println(request.log().all());

        postresponse = request.post();
        resBody = postresponse.getBody();
        bodyJson = resBody.jsonPath();

    }
  //THỰC HIỆN TESTCASE, CÀI ĐẶT THỨ TỰ ƯU TIÊN TEST NẾU CẦN
    @Test(priority = 1)
    public void T01_StatusCodeTest() {
        assertEquals(200, postresponse.getStatusCode(), "Status Check Failed!");
        System.out.println(" " + postresponse.asPrettyString());
    }

    @Test(priority = 2)
    public void T02_MessageValidateChecked() {
        assertTrue(postresponse.asString().contains("message"), "message field check Failed!");
    }

    @Test(priority = 3)
    public void T03_MessageContentChecked() {
    	 String resMessage = bodyJson.get("message");
        assertEquals(resMessage, "Đăng nhập thành công", "message field check Failed!");
    }
   
    @Test(priority = 4)
    public void TC04_ValidateToken() throws Exception {
        // Kiểm chứng response body có chứa trường token hay không
        token = bodyJson.getString("token");
        assertTrue(postresponse.asString().contains("token"), "Token field check Failed!");
        FileWriter file = new FileWriter("./RequestPayload/token.json");
        file.write("{\"token\":\"" + token + "\"}"); // 
        file.close();
        System.out.println("Token saved and writen to token.json successful");
    }
    
	@Test(priority = 5)
	public void TC05_ValidateUser() {
// Kiểm chứng response chứa thông tin user hay không
        assertTrue(postresponse.asString().contains("user"), "User field check Failed!");
	}
		
	@Test(priority = 6)
	public void TC06_ValidateUserType() {
// Kiểm chứng response body có chứa thông tin trường type hay không
        assertTrue(postresponse.asString().contains("type"), "Type field check Failed!");
	}
	
	@Test(priority = 7)
    public void TC07_VerifyOnMatchType() {

// Kiểm chứng trường type nội dung có phải là “UNGVIEN” hay không
		assertEquals(bodyJson.getString("user.type"),"UNGVIEN", "Type check Failed!");
	}

	@Test(priority = 8)
	public void TC08_ValidateAccount() {
// Kiểm chứng response body có chứa thông tin trường account hay không
        assertTrue(postresponse.asString().contains("account"), "account field check Failed!");
	}
	
	@Test(priority = 9)
	public void TC09_VerifyOnMatchAccount() {
// Kiểm chứng trường account có khớp với account đăng nhập đã cho hay không
		assertEquals(bodyJson.getString("user.account"), "testerFunix","Account check Failed!");
	}
	
	@Test(priority = 10)
	public void TC10_ValidatePassword()  {
 // Kiểm chứng response chứa thông tin trường password hay không
        assertTrue(postresponse.asString().contains("password"), "Type field check Failed!");
	}
	
	@Test(priority = 11)
	public void TC11_VerifyOnMatchPassword() {
// Kiểm chứng trường password có khớp với password đăng nhập đã cho hay không
		assertEquals(bodyJson.getString("user.password"), "Abc13579","Password check Failed!");

	}

}
