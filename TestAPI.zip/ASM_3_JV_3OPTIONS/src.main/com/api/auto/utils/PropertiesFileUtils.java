package com.api.auto.utils;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesFileUtils {

//Tạo đường dẫn đến properties files trong folder Properties
    public static String CONFIG_PATH = "./Properties/Config.properties";
//Tạo đường dẫn đến token properties files trong folder Properties
    public static String TOKEN_PATH = "./Properties/Token.properties";
    
// Lấy ra giá trị property bất kỳ theo key.
    public static String getProperty(String key) {
    	Properties properties= new Properties();
        String value = null;
        FileInputStream fileInput = null;
//Tạo exception nếu giá trị cần đọc rỗng
        try {
        	fileInput = new FileInputStream(CONFIG_PATH);
            properties.load(fileInput);
            value = properties.getProperty(key); 
            
            if (value != null) {
                value = value.trim(); 
            }
            return value;
        }catch (Exception ex) {
            System.out.println("Xảy ra lỗi khi đọc giá trị của  " + key);
            ex.printStackTrace();
        } finally {
		//luôn nhảy vào đây dù có xảy ra exception hay không.
		//thực hiện đóng luồng đọc
		if (fileInput!= null) {
			try {
				fileInput.close();
			} catch (IOException e) {
				e.printStackTrace();
				}
			}
        }
        return value;
    }
 
// Lưu token vào file token.properties với key là “token”
    public static void saveToken(String key, String value) {
        Properties properties= new Properties();
        FileOutputStream fileOutput = null;
//Tạo exception nếu giá trị cần lưu rỗng

        try {
        	fileOutput = new FileOutputStream(TOKEN_PATH);
            properties.setProperty(key, value);
            properties.store(fileOutput, value);
            System.out.println("Set new value in file Token.properties success.");
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (fileOutput!= null) {
                try {
                    fileOutput.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
// Lấy ra token đã lưu
 	public static String getToken(String key) {
 		Properties properties= new Properties();
        String value = null;
 		FileInputStream fileInput = null;
//Tạo exception nếu giá trị cần đọc rỗng
 		try {
 			fileInput = new FileInputStream(TOKEN_PATH);
            properties.load(fileInput);
            value = properties.getProperty(key); 	// nếu không có key, trả về một chuỗi rỗng 
            if (value != null) {
                value = value.trim(); 				// loại bỏ khoảng trắng đầu, cuối chuỗi
            }
            return value;
 		} catch (Exception ex) {
 			System.out.println("Xảy ra lỗi khi đọc giá trị của token " + key);
            ex.printStackTrace();
 		} finally {
 			if (fileInput != null) {
 				try {
 					fileInput.close();
 				}catch (IOException e) {
 					e.printStackTrace();
 					}
 				}
 			}
 		return value;
 	}
}
